using Microsoft.EntityFrameworkCore;
using System.Configuration;
using WebApplication3.Services;

namespace WebApplication3
{//html
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();
            builder.Services.AddDbContext<Data.Context.SampleDbContext>(config =>
            {
                //config.UseSqlServer("Data Source=DESKTOP-3O7BVCK\\SQLEXPRESS;Initial Catalog=SampleDb;Integrated Security=True;Trust Server Certificate=True");
                config.UseSqlServer(builder.Configuration["ConnectionStrings:DefaultConnection"]);
            });
            builder.Services.AddScoped(typeof(IEventsService), typeof(EventsService));
            //Console.ReadLine();

            var app = builder.Build();
            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=MainProcess}/{action=WelcomePage}/{id?}/");
            //pattern: "{controller=EventsAdmin}/{action=Create}/{id?}/");
            //pattern: "{controller=EventsAdmin}/{action=Details}/{id?}/");
            //pattern: "{controller=EventsAdmin}/{action=Index}/{id?}/");

            app.Run();
        }
    }
}
