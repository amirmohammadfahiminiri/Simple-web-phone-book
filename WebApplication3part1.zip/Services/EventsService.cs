﻿using WebApplication3.Data;
using WebApplication3.Data.Context;

namespace WebApplication3.Services
{
    public class EventsService : IEventsService
    {
        SampleDbContext dbContext;
        public EventsService(SampleDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public List<Event> Read()
        {
            return this.dbContext.Events.Where(a=>a.Aliveness).ToList();
        }
        public void Create(Event model)
        {
            this.dbContext.Events.Add(model);
            Save();
        }
        public void Update(Event model)
        {

            this.dbContext.Events.Update(model);
            Save();
        }
        public void Delete(int Id)
        {
            Event moodel = this.dbContext.Events.Find(Id);
            this.dbContext.Events.Remove(moodel);
            Save();
        }
        private void Save()
        {
            this.dbContext.SaveChanges();
        }
    }
}
