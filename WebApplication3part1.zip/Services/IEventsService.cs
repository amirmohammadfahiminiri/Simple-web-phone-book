﻿using WebApplication3.Data;

namespace WebApplication3.Services
{
    public interface IEventsService
    {
        void Create(Event model);
        void Delete(int Id);
        List<Event> Read();
        void Update(Event model);
    }
}