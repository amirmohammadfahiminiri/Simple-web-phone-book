﻿namespace WebApplication3.Data
{
    public class Event
    {
        public string UserInfo { get; set; }
        public string Username { get; set; }
        public int Id { get; set; }
        //public string Name { get; set; }
        public string UserEmailAddress { get; set; }
        public int PhoneNumber { get; set; }
        public string Password { get; set; }
        public bool Aliveness { get; set; }
        public ICollection<UserPhoneNumber> UserPhoneNumbers { get; set; }
    }
}
