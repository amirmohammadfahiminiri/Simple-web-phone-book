﻿using Microsoft.EntityFrameworkCore;

namespace WebApplication3.Data.Context
{
    public class SampleDbContext : DbContext
    {
        public SampleDbContext(DbContextOptions<SampleDbContext> options)
            : base(options)
        {
            
        }
        public DbSet<Event> Events { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Event>().HasKey(a => a.Id);
            modelBuilder.Entity<Event>().HasMany(a => a.UserPhoneNumbers)
                .WithOne(a=>a.Event).HasForeignKey(a=>a.EventId);
            base.OnModelCreating(modelBuilder);
        }
    }
}
