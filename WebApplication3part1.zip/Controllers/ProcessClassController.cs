﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplication3.Models;
using System.IO;
namespace WebApplication3.Controllers
{
    public class ProcessClassController : Controller
    {
        string DBTextFilePath = "E:\\programming\\local training\\WebApplication3\\wwwroot\\DBFile\\DBTextFile.txt";
        static string UsersCountTextFilePath = "E:\\programming\\local training\\WebApplication3\\wwwroot\\DBFile\\DBUsersCount.txt";
        static int usersCount = Convert.ToInt32(System.IO.File.ReadAllText(UsersCountTextFilePath));
        static string StarsLine(int count)
        {
            string stars = "";
            for (int i = 0; i < count; i++)
            {
                stars += "*";
            }
            usersCount++;
            System.IO.File.WriteAllText(UsersCountTextFilePath, Convert.ToString(usersCount));
            stars += usersCount;
            stars += "\r\n";
            return stars;
        }

        [HttpPost]
        public IActionResult Index(Models.UserSignUpInfoModel User)
        {
            string username = User.Username;
            string userEmailAddress = User.UserEmailAddress;
            string phoneNumber = User.PhoneNumber;
            string password = User.Password;
            string existingContent = System.IO.File.ReadAllText(DBTextFilePath);
            User.UserInfo = username + "\r\n" + userEmailAddress + "\r\n" + (phoneNumber) + "\r\n" + password;

            FileStream fs = new FileStream(DBTextFilePath, FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            sw.Write(existingContent);
            sw.Write(StarsLine(16));
            sw.Write(User.UserInfo + "\r\n");
            sw.Close();
            fs.Close();

            //Console.WriteLine(username + "\r\n" + userEmailAddress + "\r\n" + password + "\r\n" + "End1" + "\r\n" + User.UserInfo + "\r\n" + "End");

            return Redirect($"/MainProcess/ShowSomePictures/?message=Dear {username} You are subscribed");
        }
    }
}
