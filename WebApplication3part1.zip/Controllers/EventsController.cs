﻿using Microsoft.AspNetCore.Mvc;
using WebApplication3.Data.Context;
using WebApplication3.Services;

namespace WebApplication3.Controllers
{
    public class EventsController : Controller
    {
        //SampleDbContext DbContext;
        IEventsService EventsService;
        public EventsController(IEventsService service)
        {
            EventsService = service;
        }
        [Route("Index")]
        [Route("~/events/Lists")]
        public IActionResult Index()
        {
            //var events = DbContext.Events.Where(a => a.Aliveness == true).OrderBy(a => a.UserEmailAddress).ToList();
            var events = this.EventsService.Read();
            ViewBag.ThisPageTitle = "Events Lists";
            ViewBag["PageTitle"] = "You can view all events here.";
            return View(events);
        }
    }
}
