﻿using Microsoft.AspNetCore.Mvc;
using WebApplication3.Data.Context;

namespace WebApplication3.Controllers
{
    public class MainProcessController : Controller
    {
        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult SignUpPage()
        {
            return View();
        }
        public IActionResult WelcomePage()
        {
            return View();
        }
        public IActionResult ShowSomePictures(string message)
        {
            ViewBag.Message = message;
            return View();
        }
    }
}
