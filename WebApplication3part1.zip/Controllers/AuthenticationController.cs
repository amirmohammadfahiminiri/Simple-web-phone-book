﻿using Microsoft.AspNetCore.Mvc;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    public class AuthenticationController : Controller
    {
        [HttpGet]
        public IActionResult LogIn()
        {
            return View(new LogInModel());
        }
        [HttpPost]
        public IActionResult LogIn(Models.LogInModel logInModel)
        {
            if(this.ModelState.IsValid)
            {
            ViewData["Message"] = "Thank you, you are loged in.";
            return View();
            }
            ViewData["Message"] = "You sent us wrong information.";
            return View();
        }
    }
}
